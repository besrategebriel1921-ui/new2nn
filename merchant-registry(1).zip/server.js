const express=require('express'),{Pool}=require('pg'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken');
const app=express();app.use(express.json());app.use(express.static(__dirname+'/public'));
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:/localhost|127[.]0[.]0[.]1/.test(process.env.DATABASE_URL||'')?false:{rejectUnauthorized:false}});
const SECRET=process.env.JWT_SECRET||'change-this-secret';
const q=(t,p)=>pool.query(t,p).then(r=>r.rows);
const log=(u,a,d)=>q('insert into activity(user_id,username,action,detail) values($1,$2,$3,$4)',[u.id,u.username,a,d||'']);
const wrap=f=>(req,res)=>f(req,res).catch(e=>{console.error(e);const dup=e.code==='23505';res.status(dup?409:500).json({error:dup?'Already exists (UID, username or type)':'Server error'})});
const auth=(...roles)=>async(req,res,next)=>{
  let u;try{const {id}=jwt.verify((req.headers.authorization||'').slice(7),SECRET);[u]=await q('select id,username,full_name,role from users where id=$1 and active',[id])}catch(e){}
  if(!u)return res.status(401).json({error:'Please sign in'});
  if(roles.length&&!roles.includes(u.role))return res.status(403).json({error:'Not allowed'});
  req.u=u;next()};
const scope=u=>u.role==='staff'?[' where m.created_by=$1',[u.id]]:['',[]];
const bad=(res,m)=>res.status(400).json({error:m});
const ROLES=['admin','manager','director','staff'];

async function init(){
  await q(`create table if not exists users(id serial primary key,username text unique not null,full_name text not null,role text not null,password_hash text not null,active boolean default true,created_at timestamptz default now())`);
  await q(`create table if not exists merchant_types(id serial primary key,name text unique not null)`);
  await q(`create table if not exists merchants(id serial primary key,name text not null,uid text unique not null,account_number text not null,business_type text not null,address text not null,merchant_type text not null,created_by int references users(id),created_at timestamptz default now())`);
  await q(`create table if not exists activity(id serial primary key,user_id int,username text,action text,detail text,at timestamptz default now())`);
  for(const t of ['Biller Merchant','POS Merchant','Salary Merchant','School Merchant'])await q('insert into merchant_types(name) values($1) on conflict do nothing',[t]);
  if(!(await q("select 1 from users where role='admin'")).length)
    await q('insert into users(username,full_name,role,password_hash) values($1,$2,$3,$4)',['admin','System Admin','admin',await bcrypt.hash(process.env.ADMIN_PASSWORD||'Admin@123',10)]);
}

app.post('/api/login',wrap(async(req,res)=>{
  const [u]=await q('select * from users where username=lower($1) and active',[req.body.username||'']);
  if(!u||!(await bcrypt.compare(req.body.password||'',u.password_hash)))return res.status(401).json({error:'Wrong username or password'});
  await log(u,'LOGIN');
  res.json({token:jwt.sign({id:u.id},SECRET,{expiresIn:'12h'}),user:{id:u.id,username:u.username,full_name:u.full_name,role:u.role}})}));
app.get('/api/me',auth(),(req,res)=>res.json(req.u));
app.post('/api/password',auth(),wrap(async(req,res)=>{
  const {old,password}=req.body;if(!password||password.length<6)return bad(res,'Min 6 characters');
  const [u]=await q('select password_hash from users where id=$1',[req.u.id]);
  if(!(await bcrypt.compare(old||'',u.password_hash)))return bad(res,'Current password is wrong');
  await q('update users set password_hash=$1 where id=$2',[await bcrypt.hash(password,10),req.u.id]);await log(req.u,'CHANGE_PASSWORD');res.json({ok:1})}));

app.get('/api/types',auth(),wrap(async(_,res)=>res.json(await q('select * from merchant_types order by id'))));
app.post('/api/types',auth('admin'),wrap(async(req,res)=>{
  const n=(req.body.name||'').trim();if(!n)return bad(res,'Name required');
  await q('insert into merchant_types(name) values($1)',[n]);await log(req.u,'ADD_TYPE',n);res.json({ok:1})}));

app.get('/api/merchants',auth(),wrap(async(req,res)=>{
  const [w,p]=scope(req.u);
  res.json(await q(`select m.*,u.full_name staff from merchants m join users u on u.id=m.created_by${w} order by m.id desc limit 1000`,p))}));
app.post('/api/merchants',auth('staff'),wrap(async(req,res)=>{
  const b=req.body,k=['name','uid','account_number','business_type','address','merchant_type'];
  if(!k.every(x=>b[x]&&String(b[x]).trim()))return bad(res,'All fields are required');
  if(!(await q('select 1 from merchant_types where name=$1',[b.merchant_type])).length)return bad(res,'Unknown merchant type');
  await q('insert into merchants(name,uid,account_number,business_type,address,merchant_type,created_by) values($1,$2,$3,$4,$5,$6,$7)',[...k.map(x=>String(b[x]).trim()),req.u.id]);
  await log(req.u,'ADD_MERCHANT',`${b.name} (${b.uid})`);res.json({ok:1})}));

app.get('/api/dashboard',auth(),wrap(async(req,res)=>{
  const [w,p]=scope(req.u),f=`from merchants m join users u on u.id=m.created_by${w}`,mgr=req.u.role!=='staff';
  const [t]=await q(`select count(*)::int total,(count(*) filter(where m.created_at>now()-interval '7 days'))::int week,(count(*) filter(where m.created_at::date=now()::date))::int today ${f}`,p);
  res.json({...t,
    types:await q(`select m.merchant_type k,count(*)::int n ${f} group by 1 order by 2 desc`,p),
    staff:mgr?await q(`select u.full_name k,count(*)::int n ${f} group by 1 order by 2 desc`,p):[]})}));

app.get('/api/users',auth('admin'),wrap(async(_,res)=>res.json(await q('select id,username,full_name,role,active from users order by id'))));
app.post('/api/users',auth('admin'),wrap(async(req,res)=>{
  const {username,full_name,role,password}=req.body;
  if(!username||!full_name||!ROLES.includes(role)||!password||password.length<6)return bad(res,'Fill all fields (password min 6)');
  await q('insert into users(username,full_name,role,password_hash) values(lower($1),$2,$3,$4)',[username.trim(),full_name.trim(),role,await bcrypt.hash(password,10)]);
  await log(req.u,'CREATE_USER',`${username} (${role})`);res.json({ok:1})}));
app.post('/api/users/:id/reset',auth('admin'),wrap(async(req,res)=>{
  const p=req.body.password;if(!p||p.length<6)return bad(res,'Min 6 characters');
  await q('update users set password_hash=$1 where id=$2',[await bcrypt.hash(p,10),req.params.id]);await log(req.u,'RESET_PASSWORD','user #'+req.params.id);res.json({ok:1})}));
app.post('/api/users/:id/toggle',auth('admin'),wrap(async(req,res)=>{
  if(+req.params.id===req.u.id)return bad(res,'Cannot disable yourself');
  await q('update users set active=not active where id=$1',[req.params.id]);await log(req.u,'TOGGLE_USER','user #'+req.params.id);res.json({ok:1})}));
app.get('/api/activity',auth('admin'),wrap(async(_,res)=>res.json(await q('select * from activity order by id desc limit 300'))));

init().then(()=>app.listen(process.env.PORT||3000,()=>console.log('Running'))).catch(e=>{console.error(e);process.exit(1)});
